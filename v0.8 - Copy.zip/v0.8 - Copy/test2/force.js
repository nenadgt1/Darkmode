function applyCustomDarkModeSettings() {
    const darkModeClass = 'dark-mode';
    const body = document.body;

    // Elements to be forced into dark mode
    const forceDarkModeSelectors = ['.force-dark', '#force-dark-element', 'button']; // Example selectors

    // Elements to be excluded from dark mode
    const excludeDarkModeSelectors = ['.exclude-dark', '#exclude-dark-element', 'a']; // Example selectors

    // Apply forced dark mode
    forceDarkModeSelectors.forEach(selector => {
        document.querySelectorAll(selector).forEach(element => {
            element.style.backgroundColor = '#1e1e1e';
            element.style.color = '#ffffff';  // Changed to white
        });
    });

    // Apply exclusion from dark mode
    if (body.classList.contains(darkModeClass)) {
        excludeDarkModeSelectors.forEach(selector => {
            document.querySelectorAll(selector).forEach(element => {
                element.classList.toggle('dark-mode');
                element.classList.toggle('dark-mode');
            });
        });
    }
}