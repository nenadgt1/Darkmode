function applyCustomDarkModeSettings() {
    const darkModeClass = 'dark-mode';
    const body = document.body;

    // Elements to be forced into dark mode
    const forceDarkModeSelectors = ['.w3-container', '.w3-sand', '.w3-leftbar'];

    // Elements to be excluded from dark mode
    const excludeDarkModeSelectors = ['.w3-button'];

    // Apply forced dark mode
    forceDarkModeSelectors.forEach(selector => {
        document.querySelectorAll(selector).forEach(element => {
            element.style.backgroundColor = '#1e1e1e';
            element.style.color = '#ffffff';
            console.log("Forced dark mode applied");
        });
    });

    // Apply exclusion from dark mode
    if (body.classList.contains(darkModeClass)) {
        excludeDarkModeSelectors.forEach(selector => {
            document.querySelectorAll(selector).forEach(element => {
                element.classList.remove(darkModeClass);
                console.log("Excluded from dark mode");
            });
        });
    }
}
