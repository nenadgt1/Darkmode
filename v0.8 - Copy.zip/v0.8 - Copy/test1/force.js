// Define the arrays for classes to be excluded or forced into dark mode
const excludedClasses = ['.w3-input'];  // Add additional class selectors as needed
const forcedClasses = ['.force-dark-mode'];     // Add additional class selectors as needed

// Function to handle selective exclusions and inclusions
function handleExclusions() {
    if (document.body.classList.contains('dark-mode')) {
        applySelectiveAdjustments();
    } else {
        removeSelectiveAdjustments();
    }
}

// Function to apply selective adjustments for dark mode
function applySelectiveAdjustments() {
    // Apply exclusion styles dynamically
    excludedClasses.forEach(className => {
        document.querySelectorAll(className).forEach(el => {
            excludeFromDarkMode(el);
        });
    });

    // Apply force dark mode styles dynamically
    forcedClasses.forEach(className => {
        document.querySelectorAll(className).forEach(el => {
            forceIntoDarkMode(el);
        });
    });
}

// Function to remove selective adjustments for dark mode
function removeSelectiveAdjustments() {
    // Remove exclusion styles dynamically
    excludedClasses.forEach(className => {
        document.querySelectorAll(className).forEach(el => {
            removeExclusionStyles(el);
        });
    });

    // Remove force dark mode styles dynamically
    forcedClasses.forEach(className => {
        document.querySelectorAll(className).forEach(el => {
            removeForcedStyles(el);
        });
    });
}

// Function to exclude an element from dark mode
function excludeFromDarkMode(element) {
    // Store original styles
    element.dataset.originalBackgroundColor = element.style.backgroundColor;
    element.dataset.originalColor = element.style.color;

    // Apply styles to reset dark mode effect
    element.style.backgroundColor = '';
    element.style.color = '';
    element.style.filter = 'none';
}

// Function to force an element into dark mode
function forceIntoDarkMode(element) {
    // Store original styles
    element.dataset.originalBackgroundColor = element.style.backgroundColor;
    element.dataset.originalColor = element.style.color;

    // Apply dark mode styles
    element.style.backgroundColor = '#1e1e1e'; // Dark background color
    element.style.color = '#ffffff';          // Light text color
}

// Function to remove exclusion styles
function removeExclusionStyles(element) {
    // Revert to original styles
    element.style.backgroundColor = element.dataset.originalBackgroundColor || '';
    element.style.color = element.dataset.originalColor || '';
    element.style.filter = '';
}

// Function to remove forced dark mode styles
function removeForcedStyles(element) {
    // Revert to original styles
    element.style.backgroundColor = element.dataset.originalBackgroundColor || '';
    element.style.color = element.dataset.originalColor || '';
}

// Ensure this script is ready to handle exclusions immediately
document.addEventListener('DOMContentLoaded', handleExclusions);
